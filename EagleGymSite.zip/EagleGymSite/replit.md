# Eagle Gym - Fitness Website

## Overview

Eagle Gym is a modern, full-stack fitness website for a gym located in Ajman, UAE. The application features a sleek single-page layout with sections for services, pricing, gallery, and contact information. Built with React, TypeScript, and modern web technologies, it provides an engaging user experience with smooth animations and responsive design. The site includes a contact form system with email notifications and database storage for lead management.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development
- **Routing**: Wouter for lightweight client-side routing
- **Styling**: Tailwind CSS with custom CSS variables for theming, using a dark theme with red accent colors
- **UI Components**: Radix UI primitives with shadcn/ui component system for consistent, accessible components
- **Animations**: Framer Motion for smooth page transitions and scroll-based animations
- **State Management**: TanStack Query (React Query) for server state management and API calls
- **Forms**: React Hook Form with Zod validation for type-safe form handling

### Backend Architecture
- **Runtime**: Node.js with TypeScript and ES modules
- **Framework**: Express.js for REST API endpoints
- **Development**: TSX for TypeScript execution and hot reloading
- **Build System**: esbuild for production builds with Vite for frontend bundling
- **Storage**: In-memory storage with interface design for easy database migration
- **Email**: Nodemailer integration for contact form notifications

### Data Storage Solutions
- **Current**: In-memory storage using Maps for development and testing
- **Future-Ready**: Drizzle ORM configured for PostgreSQL migration
- **Database Schema**: Defined with Drizzle schema for users and contacts tables
- **Migration Support**: Drizzle Kit configured for schema migrations

### Authentication and Authorization
- **Design**: Basic user schema defined but not currently implemented
- **Preparation**: User authentication system architecture in place for future expansion
- **Session Management**: Framework prepared for session-based authentication

### External Dependencies
- **Database**: Neon Database (PostgreSQL) configured via Drizzle
- **Email Service**: Gmail SMTP integration for contact form notifications  
- **UI Framework**: Comprehensive Radix UI component library
- **Development Tools**: Vite with React plugin, PostCSS with Tailwind
- **Form Validation**: Zod for runtime type checking and validation
- **Fonts**: Google Fonts integration (Inter, Architects Daughter, DM Sans, Fira Code, Geist Mono)

### Key Architectural Decisions
- **Monorepo Structure**: Client, server, and shared code in unified structure
- **Type Sharing**: Shared schema definitions between frontend and backend
- **Component Architecture**: Modular section-based components for maintainability  
- **Responsive Design**: Mobile-first approach with Tailwind responsive utilities
- **Performance**: Optimized images, lazy loading, and efficient bundle splitting
- **Accessibility**: ARIA-compliant components via Radix UI primitives
- **Development Experience**: Hot reloading, TypeScript checking, and modern tooling