import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactSchema, type InsertContact } from "@shared/schema";
import { z } from "zod";
import nodemailer from "nodemailer";

// Create email transporter (configured for Gmail, can be changed)
const createEmailTransporter = () => {
  return nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.EMAIL_USER || process.env.GMAIL_USER || 'your-email@gmail.com',
      pass: process.env.EMAIL_PASS || process.env.GMAIL_PASS || 'your-app-password'
    }
  });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Contact form submission endpoint
  app.post("/api/contact", async (req, res) => {
    try {
      // Validate request body
      const contactData = insertContactSchema.parse(req.body) as InsertContact;
      
      // Store contact in database
      const contact = await storage.createContact(contactData);
      
      // Send email notification
      try {
        const transporter = createEmailTransporter();
        
        // Email to gym owner
        await transporter.sendMail({
          from: process.env.EMAIL_USER || process.env.GMAIL_USER || 'your-email@gmail.com',
          to: 'info@eaglegym.ae',
          subject: `New Contact Form Submission - ${contactData.interest}`,
          html: `
            <h2>New Contact Form Submission</h2>
            <p><strong>Name:</strong> ${contactData.firstName} ${contactData.lastName}</p>
            <p><strong>Email:</strong> ${contactData.email}</p>
            <p><strong>Phone:</strong> ${contactData.phone}</p>
            <p><strong>Interest:</strong> ${contactData.interest}</p>
            <p><strong>Message:</strong></p>
            <p>${contactData.message}</p>
          `
        });
        
        // Confirmation email to customer
        await transporter.sendMail({
          from: process.env.EMAIL_USER || process.env.GMAIL_USER || 'your-email@gmail.com',
          to: contactData.email,
          subject: 'Thank you for contacting Eagle Gym!',
          html: `
            <h2>Thank you for your interest in Eagle Gym!</h2>
            <p>Dear ${contactData.firstName},</p>
            <p>We have received your message and will get back to you soon.</p>
            <p><strong>Your message:</strong></p>
            <p>${contactData.message}</p>
            <br>
            <p>Best regards,<br>Eagle Gym Team</p>
            <p>📍 ADCB Building - Al Ittihad Street, Al Bustan - Ajman</p>
            <p>📞 +971 055 843 4989</p>
          `
        });
      } catch (emailError) {
        console.error('Email sending failed:', emailError);
        // Don't fail the request if email fails
      }
      
      res.json({ 
        success: true, 
        message: 'Contact form submitted successfully',
        contact: {
          id: contact.id,
          firstName: contact.firstName,
          lastName: contact.lastName,
          email: contact.email
        }
      });
      
    } catch (error) {
      console.error('Contact form error:', error);
      
      if (error instanceof z.ZodError) {
        res.status(400).json({ 
          success: false, 
          message: 'Invalid form data', 
          errors: error.errors 
        });
      } else {
        res.status(500).json({ 
          success: false, 
          message: 'Failed to submit contact form' 
        });
      }
    }
  });

  // Get all contacts (for admin purposes)
  app.get("/api/contacts", async (req, res) => {
    try {
      const contacts = await storage.getContacts();
      res.json({ contacts });
    } catch (error) {
      console.error('Get contacts error:', error);
      res.status(500).json({ 
        success: false, 
        message: 'Failed to retrieve contacts' 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
