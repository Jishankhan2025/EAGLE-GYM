import { Facebook, Instagram, MessageCircle } from "lucide-react";

export default function Footer() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    element?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <footer className="bg-background border-t border-border py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center space-x-3 mb-4">
              <img 
                src="https://lh3.googleusercontent.com/p/AF1QipNNtuKP_MNg6YZtGMPUcJAVKlxMzzEHwDFvCYL0=s680-w680-h510-rw" 
                alt="Eagle Gym Logo" 
                className="h-8 w-8 rounded" 
              />
              <span className="text-lg font-bold gradient-text">Eagle Gym</span>
            </div>
            <p className="text-muted-foreground mb-4">
              Soar to new heights with Eagle Gym. Your premier fitness destination in Ajman.
            </p>
            <div className="flex space-x-3">
              <button className="text-muted-foreground hover:text-primary transition-colors" data-testid="footer-facebook">
                <Facebook className="h-5 w-5" />
              </button>
              <button className="text-muted-foreground hover:text-primary transition-colors" data-testid="footer-instagram">
                <Instagram className="h-5 w-5" />
              </button>
              <button className="text-muted-foreground hover:text-primary transition-colors" data-testid="footer-whatsapp">
                <MessageCircle className="h-5 w-5" />
              </button>
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <button 
                  onClick={() => scrollToSection("home")} 
                  className="text-muted-foreground hover:text-primary transition-colors"
                  data-testid="footer-home"
                >
                  Home
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection("about")} 
                  className="text-muted-foreground hover:text-primary transition-colors"
                  data-testid="footer-about"
                >
                  About
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection("services")} 
                  className="text-muted-foreground hover:text-primary transition-colors"
                  data-testid="footer-services"
                >
                  Services
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection("pricing")} 
                  className="text-muted-foreground hover:text-primary transition-colors"
                  data-testid="footer-pricing"
                >
                  Pricing
                </button>
              </li>
            </ul>
          </div>
          
          {/* Programs */}
          <div>
            <h4 className="font-semibold mb-4">Programs</h4>
            <ul className="space-y-2">
              <li><span className="text-muted-foreground">Strength Training</span></li>
              <li><span className="text-muted-foreground">Cardio Fitness</span></li>
              <li><span className="text-muted-foreground">Group Classes</span></li>
              <li><span className="text-muted-foreground">Personal Training</span></li>
            </ul>
          </div>
          
          {/* Contact Info */}
          <div>
            <h4 className="font-semibold mb-4">Contact</h4>
            <div className="space-y-2 text-muted-foreground text-sm">
              <p>ADCB Building, Al Ittihad Street</p>
              <p>Al Bustan, Ajman</p>
              <p>+971 055 843 4989</p>
              <p>info@eaglegym.ae</p>
            </div>
          </div>
        </div>
        
        <div className="border-t border-border mt-8 pt-8 text-center">
          <p className="text-muted-foreground text-sm">
            © 2024 Eagle Gym. All rights reserved. | Privacy Policy | Terms of Service
          </p>
        </div>
      </div>
    </footer>
  );
}
