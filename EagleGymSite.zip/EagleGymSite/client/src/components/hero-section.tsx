import { Button } from "@/components/ui/button";
import { Dumbbell, Play, ChevronDown } from "lucide-react";
import { motion } from "framer-motion";

export default function HeroSection() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    element?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center hero-bg">
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080" 
          alt="Mixed gender gym training session" 
          className="w-full h-full object-cover opacity-30" 
        />
      </div>
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="max-w-4xl mx-auto">
          <motion.h1 
            className="text-5xl md:text-7xl font-black mb-6 leading-tight"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            UNLEASH YOUR
            <span className="gradient-text block">INNER EAGLE</span>
          </motion.h1>
          
          <motion.p 
            className="text-xl md:text-2xl text-muted-foreground mb-8 font-medium"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            Transform your body, elevate your mind. Join Ajman's premier fitness destination.
          </motion.p>
          
          <motion.div 
            className="flex flex-col sm:flex-row gap-4 justify-center"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            <Button 
              size="lg"
              className="bg-primary text-primary-foreground px-8 py-4 text-lg font-bold hover:bg-accent transition-all transform hover:scale-105 pulse-red"
              onClick={() => scrollToSection("pricing")}
              data-testid="button-start-journey"
            >
              <Dumbbell className="mr-2 h-5 w-5" />
              Start Your Journey
            </Button>
            <Button 
              variant="outline"
              size="lg"
              className="border-2 border-primary text-primary px-8 py-4 text-lg font-bold hover:bg-primary hover:text-primary-foreground transition-all"
              data-testid="button-watch-story"
            >
              <Play className="mr-2 h-5 w-5" />
              Watch Our Story
            </Button>
          </motion.div>
        </div>
      </div>
      
      <motion.div 
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-primary cursor-pointer"
        animate={{ y: [0, -10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
        onClick={() => scrollToSection("about")}
        data-testid="scroll-indicator"
      >
        <ChevronDown className="h-8 w-8" />
      </motion.div>
    </section>
  );
}
