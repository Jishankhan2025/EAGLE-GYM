import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

export default function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    element?.scrollIntoView({ behavior: "smooth" });
    setIsMobileMenuOpen(false);
  };

  return (
    <nav
      className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        isScrolled ? "bg-background/95 backdrop-blur-md border-b border-border" : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-3">
            <img 
              src="https://lh3.googleusercontent.com/p/AF1QipNNtuKP_MNg6YZtGMPUcJAVKlxMzzEHwDFvCYL0=s680-w680-h510-rw" 
              alt="Eagle Gym Logo" 
              className="h-10 w-10 rounded-lg"
            />
            <span className="text-xl font-bold gradient-text">Eagle Gym</span>
          </div>

          <div className="hidden md:flex items-center space-x-8">
            <button 
              onClick={() => scrollToSection("home")} 
              className="text-foreground hover:text-primary transition-colors"
              data-testid="nav-home"
            >
              Home
            </button>
            <button 
              onClick={() => scrollToSection("about")} 
              className="text-foreground hover:text-primary transition-colors"
              data-testid="nav-about"
            >
              About
            </button>
            <button 
              onClick={() => scrollToSection("services")} 
              className="text-foreground hover:text-primary transition-colors"
              data-testid="nav-services"
            >
              Services
            </button>
            <button 
              onClick={() => scrollToSection("pricing")} 
              className="text-foreground hover:text-primary transition-colors"
              data-testid="nav-pricing"
            >
              Pricing
            </button>
            <button 
              onClick={() => scrollToSection("gallery")} 
              className="text-foreground hover:text-primary transition-colors"
              data-testid="nav-gallery"
            >
              Gallery
            </button>
            <button 
              onClick={() => scrollToSection("contact")} 
              className="text-foreground hover:text-primary transition-colors"
              data-testid="nav-contact"
            >
              Contact
            </button>
            <Button 
              className="bg-primary text-primary-foreground px-6 py-2 font-semibold hover:bg-accent pulse-red"
              onClick={() => scrollToSection("pricing")}
              data-testid="button-join-nav"
            >
              Join Now
            </Button>
          </div>

          <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden" data-testid="button-mobile-menu">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="bg-background border-border">
              <div className="flex flex-col space-y-4 mt-8">
                <button 
                  onClick={() => scrollToSection("home")} 
                  className="text-foreground hover:text-primary transition-colors text-left"
                  data-testid="mobile-nav-home"
                >
                  Home
                </button>
                <button 
                  onClick={() => scrollToSection("about")} 
                  className="text-foreground hover:text-primary transition-colors text-left"
                  data-testid="mobile-nav-about"
                >
                  About
                </button>
                <button 
                  onClick={() => scrollToSection("services")} 
                  className="text-foreground hover:text-primary transition-colors text-left"
                  data-testid="mobile-nav-services"
                >
                  Services
                </button>
                <button 
                  onClick={() => scrollToSection("pricing")} 
                  className="text-foreground hover:text-primary transition-colors text-left"
                  data-testid="mobile-nav-pricing"
                >
                  Pricing
                </button>
                <button 
                  onClick={() => scrollToSection("gallery")} 
                  className="text-foreground hover:text-primary transition-colors text-left"
                  data-testid="mobile-nav-gallery"
                >
                  Gallery
                </button>
                <button 
                  onClick={() => scrollToSection("contact")} 
                  className="text-foreground hover:text-primary transition-colors text-left"
                  data-testid="mobile-nav-contact"
                >
                  Contact
                </button>
                <Button 
                  className="bg-primary text-primary-foreground font-semibold hover:bg-accent pulse-red mt-4"
                  onClick={() => scrollToSection("pricing")}
                  data-testid="button-join-mobile"
                >
                  Join Now
                </Button>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
}
