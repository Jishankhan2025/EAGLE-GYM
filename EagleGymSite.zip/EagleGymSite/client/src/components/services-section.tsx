import { motion } from "framer-motion";
import { Dumbbell, Heart, Users, UserCheck, Zap, Activity, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ServicesSection() {
  const services = [
    {
      icon: Dumbbell,
      title: "Strength Training",
      description: "Build muscle and increase your power with our comprehensive strength training programs.",
      image: "https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250"
    },
    {
      icon: Heart,
      title: "Cardio Fitness", 
      description: "Improve your cardiovascular health with our high-energy cardio workouts.",
      image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250"
    },
    {
      icon: Users,
      title: "Group Classes",
      description: "Join our energetic group classes for motivation and community support.",
      image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250"
    },
    {
      icon: UserCheck,
      title: "Personal Training",
      description: "Get personalized attention with our certified personal trainers.",
      image: "https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250"
    },
    {
      icon: Zap,
      title: "Functional Training", 
      description: "Improve your daily movement patterns with functional fitness training.",
      image: "https://images.unsplash.com/photo-1545205597-3d9d02c29597?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250"
    },
    {
      icon: Activity,
      title: "Recovery & Wellness",
      description: "Optimize your recovery with our wellness and rehabilitation services.",
      image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250"
    }
  ];

  return (
    <section id="services" className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            OUR <span className="gradient-text">PROGRAMS</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            From strength training to cardio, we offer comprehensive programs designed to help you achieve your fitness goals.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={index}
                className="bg-card border border-border rounded-xl p-6 card-hover"
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                data-testid={`service-card-${index}`}
              >
                <img 
                  src={service.image} 
                  alt={service.title} 
                  className="w-full h-48 object-cover rounded-lg mb-4" 
                />
                <div className="text-primary text-3xl mb-4">
                  <Icon className="h-8 w-8" />
                </div>
                <h3 className="text-xl font-bold mb-3" data-testid={`service-title-${index}`}>
                  {service.title}
                </h3>
                <p className="text-muted-foreground mb-4" data-testid={`service-description-${index}`}>
                  {service.description}
                </p>
                <Button 
                  variant="link" 
                  className="text-primary font-semibold hover:text-accent transition-colors p-0"
                  data-testid={`service-learn-more-${index}`}
                >
                  Learn More <ArrowRight className="ml-1 h-4 w-4" />
                </Button>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
