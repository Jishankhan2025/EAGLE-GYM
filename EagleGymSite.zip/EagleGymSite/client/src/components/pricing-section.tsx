import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Check, Phone } from "lucide-react";

export default function PricingSection() {
  const scrollToContact = () => {
    const element = document.getElementById("contact");
    element?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section id="pricing" className="py-20 bg-secondary">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            MEMBERSHIP <span className="gradient-text">PLANS</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Choose the perfect membership plan that fits your lifestyle and fitness goals.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {/* Basic Plan */}
          <motion.div 
            className="bg-card border border-border rounded-xl p-8 relative"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            <div className="text-center">
              <h3 className="text-2xl font-bold mb-4" data-testid="plan-basic-title">Basic</h3>
              <div className="text-4xl font-black text-primary mb-2" data-testid="plan-basic-price">AED 200</div>
              <div className="text-muted-foreground mb-6">per month</div>
              <ul className="space-y-3 mb-8 text-left">
                <li className="flex items-center">
                  <Check className="text-primary mr-3 h-4 w-4" />
                  Access to gym equipment
                </li>
                <li className="flex items-center">
                  <Check className="text-primary mr-3 h-4 w-4" />
                  Locker facility
                </li>
                <li className="flex items-center">
                  <Check className="text-primary mr-3 h-4 w-4" />
                  Basic fitness assessment
                </li>
              </ul>
              <Button 
                variant="outline"
                className="w-full"
                data-testid="button-choose-basic"
              >
                Choose Plan
              </Button>
            </div>
          </motion.div>

          {/* Special Offer Plan */}
          <motion.div 
            className="bg-card border-2 border-primary rounded-xl p-8 relative transform scale-105"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            viewport={{ once: true }}
          >
            <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
              <span className="bg-primary text-primary-foreground px-4 py-2 rounded-full text-sm font-bold pulse-red">
                SPECIAL OFFER
              </span>
            </div>
            <div className="text-center">
              <h3 className="text-2xl font-bold mb-4" data-testid="plan-special-title">1 Month Special</h3>
              <div className="text-4xl font-black text-primary mb-2" data-testid="plan-special-price">AED 150</div>
              <div className="text-muted-foreground mb-6">Limited time offer</div>
              <ul className="space-y-3 mb-8 text-left">
                <li className="flex items-center">
                  <Check className="text-primary mr-3 h-4 w-4" />
                  All gym equipment access
                </li>
                <li className="flex items-center">
                  <Check className="text-primary mr-3 h-4 w-4" />
                  Group classes included
                </li>
                <li className="flex items-center">
                  <Check className="text-primary mr-3 h-4 w-4" />
                  Personal trainer consultation
                </li>
                <li className="flex items-center">
                  <Check className="text-primary mr-3 h-4 w-4" />
                  Nutrition guidance
                </li>
              </ul>
              <Button 
                className="w-full bg-primary text-primary-foreground hover:bg-accent pulse-red"
                data-testid="button-grab-deal"
              >
                Grab This Deal
              </Button>
            </div>
          </motion.div>

          {/* 3 Month Special */}
          <motion.div 
            className="bg-card border-2 border-accent rounded-xl p-8 relative"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
              <span className="bg-accent text-accent-foreground px-4 py-2 rounded-full text-sm font-bold">
                BEST VALUE
              </span>
            </div>
            <div className="text-center">
              <h3 className="text-2xl font-bold mb-4" data-testid="plan-best-title">3 Months Special</h3>
              <div className="text-4xl font-black text-primary mb-2" data-testid="plan-best-price">AED 300</div>
              <div className="text-muted-foreground mb-6">Save AED 300!</div>
              <ul className="space-y-3 mb-8 text-left">
                <li className="flex items-center">
                  <Check className="text-primary mr-3 h-4 w-4" />
                  Everything in 1 Month plan
                </li>
                <li className="flex items-center">
                  <Check className="text-primary mr-3 h-4 w-4" />
                  Priority booking for classes
                </li>
                <li className="flex items-center">
                  <Check className="text-primary mr-3 h-4 w-4" />
                  Free guest passes (2)
                </li>
                <li className="flex items-center">
                  <Check className="text-primary mr-3 h-4 w-4" />
                  Body composition analysis
                </li>
              </ul>
              <Button 
                className="w-full bg-accent text-accent-foreground hover:bg-primary"
                data-testid="button-best-value"
              >
                Best Value Deal
              </Button>
            </div>
          </motion.div>
        </div>

        <motion.div 
          className="text-center mt-12"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          viewport={{ once: true }}
        >
          <p className="text-muted-foreground mb-4">All memberships include access to changing rooms, showers, and parking.</p>
          <Button 
            className="bg-primary text-primary-foreground px-8 py-3 font-semibold hover:bg-accent transition-colors"
            onClick={scrollToContact}
            data-testid="button-custom-plans"
          >
            <Phone className="mr-2 h-4 w-4" />
            Call for Custom Plans
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
