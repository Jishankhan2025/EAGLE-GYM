import { motion } from "framer-motion";

export default function AboutSection() {
  const features = [
    "State-of-the-art equipment",
    "Certified professional trainers", 
    "24/7 access for members",
    "Community-focused environment"
  ];

  return (
    <section id="about" className="py-20 bg-secondary">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              WHERE <span className="gradient-text">CHAMPIONS</span> ARE MADE
            </h2>
            <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
              Eagle Gym has been Ajman's premier fitness destination since our founding. We believe that every individual has the potential to soar to new heights, just like the mighty eagle.
            </p>
            <div className="space-y-4">
              {features.map((feature, index) => (
                <motion.div 
                  key={index}
                  className="flex items-center space-x-3"
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <div className="w-3 h-3 bg-primary rounded-full"></div>
                  <span className="font-semibold" data-testid={`feature-${index}`}>{feature}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>
          
          <motion.div 
            className="relative"
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <img 
              src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
              alt="Modern gym interior with equipment" 
              className="rounded-xl shadow-2xl w-full h-auto" 
            />
            <div className="absolute -bottom-6 -right-6 bg-primary text-primary-foreground p-6 rounded-xl">
              <div className="text-center">
                <div className="text-3xl font-bold" data-testid="member-count">500+</div>
                <div className="text-sm">Happy Members</div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
